#include<stdio.h>
#include<stdlib.h>

int n;

int main(void){

    for ( int i = 15; i <= 30; i++ ) {

    n = i * i;

    printf("%d ", n);

    }
    
    return 0;
}