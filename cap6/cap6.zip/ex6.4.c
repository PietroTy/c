//PietroTy//
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (void)   {

    float n;

    printf("Numero: ");
    scanf("%f", &n);

    printf("Valor absoluto: %.02f\n", fabs(n));

    return 0;
}